#version 330 core

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;
in vec2 texCoord0;
in vec4 vertexColor;
out vec4 fragColor;

void main() {
    vec4 content = texture(Sampler0, texCoord0);
    float coverage = clamp(texture(Sampler1, texCoord0).r, 0.0, 1.0);
    fragColor = content * coverage * vertexColor.a;
    fragColor.rgb *= vertexColor.rgb;
}
