#version 330 core

#include <molecular:common.glsl>

in vec2 quadCoord;
in vec4 vertexColor;
in vec4 vertexData0;
in vec4 vertexData1;

out vec4 fragColor;

float gaussianCoverage(float distance) {
    float value = abs(distance);
    float t = 1.0 / (1.0 + 0.2316419 * value);
    float tail = 0.3989422804 * exp(-0.5 * value * value) * t
        * (0.319381530 + t * (-0.356563782 + t * (1.781477937
        + t * (-1.821255978 + t * 1.330274429))));
    return distance >= 0.0 ? tail : 1.0 - tail;
}

void main() {
    vec2 size = max(vertexData0.xy, vec2(0.0001));
    vec2 halfSize = size * 0.5;
    float radius = clamp(vertexData0.z, 0.0, min(halfSize.x, halfSize.y));
    float blur = max(vertexData0.w, 0.0);
    float spread = vertexData1.x;
    vec2 position = quadCoord * size - halfSize;
    float distance = roundedBoxSDF(position, halfSize, vec4(radius)) - spread;
    float edgeWidth = max(fwidth(distance) * 0.5, 0.0001);
    float sigma = sqrt(blur * blur + edgeWidth * edgeWidth);
    float alpha = gaussianCoverage(distance / sigma) * vertexColor.a;

    if (alpha <= 0.0001) {
        discard;
    }

    fragColor = vec4(vertexColor.rgb, alpha);
}
