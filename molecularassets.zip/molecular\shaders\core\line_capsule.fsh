#version 330 core

in vec2 screenPosition;
in vec4 vertexColor;
in vec4 vertexData0;
in vec4 vertexData1;

out vec4 fragColor;

void main() {
    vec2 start = vertexData0.xy;
    vec2 end = vertexData0.zw;
    float halfThickness = max(vertexData1.x, 0.0);
    float smoothness = max(vertexData1.y, 0.0);
    vec2 segment = end - start;
    float segmentLengthSquared = dot(segment, segment);
    float projection = segmentLengthSquared > 0.000001
        ? clamp(dot(screenPosition - start, segment) / segmentLengthSquared, 0.0, 1.0)
        : 0.0;
    float distance = length(screenPosition - (start + segment * projection)) - halfThickness;
    if (vertexData1.z > 0.5 && segmentLengthSquared > 0.000001) {
        float segmentLength = sqrt(segmentLengthSquared);
        vec2 direction = segment / segmentLength;
        vec2 relative = screenPosition - (start + end) * 0.5;
        vec2 local = vec2(dot(relative, direction), dot(relative, vec2(-direction.y, direction.x)));
        float extension = vertexData1.z > 1.5 ? halfThickness : 0.0;
        vec2 d = abs(local) - vec2(segmentLength * 0.5 + extension, halfThickness);
        distance = length(max(d, 0.0)) + min(max(d.x, d.y), 0.0);
    }
    float edgeWidth = max(fwidth(distance) * 0.75, max(smoothness * 0.5, 0.0001));
    float alpha = 1.0 - smoothstep(-edgeWidth, edgeWidth, distance);
    vec4 color = vec4(vertexColor.rgb, vertexColor.a * alpha);

    if (color.a <= 0.001) {
        discard;
    }
    fragColor = color;
}
