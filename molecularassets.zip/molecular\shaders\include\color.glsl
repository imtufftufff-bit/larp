vec3 srgbToLinear(vec3 color) {
    vec3 safeColor = max(color, vec3(0.0));
    return mix(pow((safeColor + 0.055) / 1.055, vec3(2.4)),
        safeColor / 12.92, lessThanEqual(safeColor, vec3(0.04045)));
}

vec3 linearToSrgb(vec3 color) {
    vec3 safeColor = max(color, vec3(0.0));
    return mix(1.055 * pow(safeColor, vec3(1.0 / 2.4)) - 0.055,
        safeColor * 12.92, lessThanEqual(safeColor, vec3(0.0031308)));
}
