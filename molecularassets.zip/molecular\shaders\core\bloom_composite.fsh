#version 330 core

uniform sampler2D Sampler0;

in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec3 bloom = texture(Sampler0, texCoord0).rgb
        * vertexColor.rgb * vertexColor.a * 0.72;

    if (max(bloom.r, max(bloom.g, bloom.b)) <= 0.0001) {
        discard;
    }
    fragColor = vec4(bloom, 0.0);
}
