#version 330 core

uniform sampler2D Sampler0;
in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec2 texel = 1.0 / vec2(textureSize(Sampler0, 0));
    vec3 color = texture(Sampler0, texCoord).rgb * 4.0;
    color += texture(Sampler0, texCoord + texel * vec2(-1.5, -1.5)).rgb;
    color += texture(Sampler0, texCoord + texel * vec2( 1.5, -1.5)).rgb;
    color += texture(Sampler0, texCoord + texel * vec2(-1.5,  1.5)).rgb;
    color += texture(Sampler0, texCoord + texel * vec2( 1.5,  1.5)).rgb;
    color += texture(Sampler0, texCoord + texel * vec2(-0.5, -0.5)).rgb * 2.0;
    color += texture(Sampler0, texCoord + texel * vec2( 0.5, -0.5)).rgb * 2.0;
    color += texture(Sampler0, texCoord + texel * vec2(-0.5,  0.5)).rgb * 2.0;
    color += texture(Sampler0, texCoord + texel * vec2( 0.5,  0.5)).rgb * 2.0;
    fragColor = vec4(color / 16.0, 0.0);
}
