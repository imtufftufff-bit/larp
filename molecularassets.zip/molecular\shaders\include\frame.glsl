layout(std140) uniform MolecularFrame {
    vec4 TargetSize;
    vec4 PixelInfo;
    vec4 FrameTime;
    vec4 ActiveUv;
    mat4 FrameView;
    mat4 FrameProjection;
    mat4 FrameViewProjection;
};
