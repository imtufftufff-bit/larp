#version 330 core

uniform sampler2D Sampler0;

in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 sampled = texture(Sampler0, texCoord0);
    float coverage = clamp(sampled.a, 0.0, 1.0);
    vec3 color = coverage > 0.0001 ? sampled.rgb / coverage : vec3(0.0);
    float maximum = max(color.r, max(color.g, color.b));
    float minimum = min(color.r, min(color.g, color.b));
    float saturation = maximum > 0.0001 ? (maximum - minimum) / maximum : 0.0;
    float luminance = dot(color, vec3(0.2126, 0.7152, 0.0722));
    float highlight = smoothstep(0.58, 0.92, max(luminance, maximum * 0.72));
    float accent = smoothstep(0.28, 0.78, saturation)
        * smoothstep(0.30, 0.82, maximum)
        * mix(0.42, 1.0, smoothstep(0.12, 0.55, luminance));
    float emission = max(highlight, accent * 0.72);
    vec3 extracted = sampled.rgb * emission * vertexColor.rgb * vertexColor.a;

    if (max(extracted.r, max(extracted.g, extracted.b)) <= 0.0001) {
        discard;
    }
    fragColor = vec4(extracted, 0.0);
}
