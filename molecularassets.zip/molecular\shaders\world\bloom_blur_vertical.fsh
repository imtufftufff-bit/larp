#version 330 core

uniform sampler2D Sampler0;
in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec2 offset = vec2(0.0, 1.0 / float(max(textureSize(Sampler0, 0).y, 1)));
    vec3 color = texture(Sampler0, texCoord).rgb * 0.2270270270;
    color += texture(Sampler0, texCoord + offset * 1.3846153846).rgb * 0.3162162162;
    color += texture(Sampler0, texCoord - offset * 1.3846153846).rgb * 0.3162162162;
    color += texture(Sampler0, texCoord + offset * 3.2307692308).rgb * 0.0702702703;
    color += texture(Sampler0, texCoord - offset * 3.2307692308).rgb * 0.0702702703;
    fragColor = vec4(color, 0.0);
}
