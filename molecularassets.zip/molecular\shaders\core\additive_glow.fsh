#version 330 core

in vec2 quadCoord;
in vec4 vertexColor;
in vec4 vertexData0;
out vec4 fragColor;

void main() {
    float radius = vertexData0.x;
    float sigma = max(vertexData0.y, 0.001);
    float variance = sigma * sigma + radius * radius * 0.25;
    vec2 delta = (quadCoord * 2.0 - 1.0) * vertexData0.z;
    float tail = exp(-8.0);
    float falloff = max(0.0, exp(-dot(delta, delta) / (2.0 * variance)) - tail);
    float energy = 1.08 * radius * radius / (2.0 * variance);
    fragColor = vec4(vertexColor.rgb * vertexColor.a * energy * falloff, 0.0);
}
