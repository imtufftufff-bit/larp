#version 330 core

uniform sampler2D Sampler0;
uniform bool TexturePremultiplied;

in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 sampled = texture(Sampler0, texCoord0);
    float alpha = sampled.a * vertexColor.a;
    vec3 rgb = sampled.rgb * vertexColor.rgb * vertexColor.a;
    if (!TexturePremultiplied) rgb *= sampled.a;
    vec4 color = vec4(rgb, alpha);

    if (color.a <= 0.001) {
        discard;
    }
    fragColor = color;
}
