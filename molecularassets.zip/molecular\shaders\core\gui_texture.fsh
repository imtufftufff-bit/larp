#version 330 core

uniform sampler2D Sampler0;

in vec2 texCoord0;
in vec2 screenPosition;
in vec4 vertexColor;
in vec4 vertexData0;

out vec4 fragColor;

void main() {
    vec4 sampled = texture(Sampler0, texCoord0);
    vec4 color = sampled * vertexColor;

    vec2 local = (screenPosition - vertexData0.xy) / max(vertexData0.zw, vec2(0.0001));
    vec2 point = abs(local * 2.0 - 1.0);
    const float radius = 0.22;
    vec2 corner = point - vec2(1.0 - radius);
    float distance = length(max(corner, vec2(0.0))) - radius;
    float edge = max(fwidth(distance) * 1.25, 0.001);
    color.a *= 1.0 - smoothstep(-edge, edge, distance);

    if (color.a <= 0.001) {
        discard;
    }
    fragColor = color;
}
