#version 330 core

uniform sampler2D Sampler0;

in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 sampled = texture(Sampler0, texCoord0);
    vec4 color = vec4(
        sampled.rgb * vertexColor.rgb * vertexColor.a,
        sampled.a * vertexColor.a
    );
    if (color.a <= 0.0001 && max(color.r, max(color.g, color.b)) <= 0.0001) {
        discard;
    }
    fragColor = color;
}
