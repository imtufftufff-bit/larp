#version 330 core

uniform sampler2D Sampler0;

in vec2 texCoord0;

out vec4 fragColor;

void main() {
    float inverseHeight = 1.0 / float(max(textureSize(Sampler0, 0).y, 1));
    vec2 offset = vec2(0.0, inverseHeight);
    vec4 color = texture(Sampler0, texCoord0) * 0.2270270270;
    color += texture(Sampler0, texCoord0 + offset * 1.3846153846) * 0.3162162162;
    color += texture(Sampler0, texCoord0 - offset * 1.3846153846) * 0.3162162162;
    color += texture(Sampler0, texCoord0 + offset * 3.2307692308) * 0.0702702703;
    color += texture(Sampler0, texCoord0 - offset * 3.2307692308) * 0.0702702703;
    fragColor = color;
}
