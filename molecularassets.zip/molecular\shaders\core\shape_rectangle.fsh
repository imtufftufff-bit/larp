#version 330 core

#include <molecular:common.glsl>

in vec2 quadCoord;
in vec4 vertexColor;
in vec4 vertexData0;
in vec4 vertexData1;

out vec4 fragColor;

void main() {
    vec4 radius = vertexData0;
    vec2 size = vertexData1.xy;
    float smoothness = vertexData1.z;
    vec2 center = size * 0.5;
    float distance = roundedBoxSDF(center - (quadCoord * size), center, radius);

    float edgeWidth = max(fwidth(distance) * 0.75, max(smoothness * 0.5, 0.0001));
    float alpha = 1.0 - smoothstep(-edgeWidth, edgeWidth, distance);
    vec4 finalColor = vec4(vertexColor.rgb, vertexColor.a * alpha);

    if (finalColor.a <= 0.001) {
        discard;
    }

    fragColor = finalColor;
}
