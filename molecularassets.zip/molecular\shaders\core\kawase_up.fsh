#version 330 core

uniform sampler2D Sampler0;
in vec2 texCoord0;
out vec4 fragColor;

void main() {
    vec2 halfPixel = 0.5 / vec2(textureSize(Sampler0, 0));
    vec4 color = texture(Sampler0, texCoord0 + vec2(-2.0 * halfPixel.x, 0.0));
    color += texture(Sampler0, texCoord0 + vec2(2.0 * halfPixel.x, 0.0));
    color += texture(Sampler0, texCoord0 + vec2(0.0, -2.0 * halfPixel.y));
    color += texture(Sampler0, texCoord0 + vec2(0.0, 2.0 * halfPixel.y));
    color += texture(Sampler0, texCoord0 + vec2(-halfPixel.x, -halfPixel.y)) * 2.0;
    color += texture(Sampler0, texCoord0 + vec2( halfPixel.x, -halfPixel.y)) * 2.0;
    color += texture(Sampler0, texCoord0 + vec2(-halfPixel.x,  halfPixel.y)) * 2.0;
    color += texture(Sampler0, texCoord0 + vec2( halfPixel.x,  halfPixel.y)) * 2.0;
    fragColor = color / 12.0;
}
