#version 330 core

uniform sampler2D Sampler0;
in vec2 texCoord0;
out vec4 fragColor;

void main() {
    vec2 halfPixel = 0.5 / vec2(textureSize(Sampler0, 0));
    vec4 color = texture(Sampler0, texCoord0) * 4.0;
    color += texture(Sampler0, texCoord0 + vec2(-halfPixel.x, -halfPixel.y));
    color += texture(Sampler0, texCoord0 + vec2( halfPixel.x, -halfPixel.y));
    color += texture(Sampler0, texCoord0 + vec2(-halfPixel.x,  halfPixel.y));
    color += texture(Sampler0, texCoord0 + vec2( halfPixel.x,  halfPixel.y));
    fragColor = color * 0.125;
}
