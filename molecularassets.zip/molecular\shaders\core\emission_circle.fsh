#version 330 core

in vec2 quadCoord;
in vec4 vertexColor;
in vec4 vertexData0;

out vec4 fragColor;

void main() {
    float radius = vertexData0.x;
    float outerRadius = vertexData0.y;
    float smoothness = max(vertexData0.z, 0.0);
    vec2 local = (quadCoord * 2.0 - 1.0) * outerRadius;
    float distance = length(local) - radius;
    float edgeWidth = max(fwidth(distance) * 0.75, max(smoothness * 0.5, 0.0001));
    float coverage = 1.0 - smoothstep(-edgeWidth, edgeWidth, distance);
    vec3 emission = vertexColor.rgb * vertexColor.a * coverage * 1.5;

    if (max(emission.r, max(emission.g, emission.b)) <= 0.0001) {
        discard;
    }
    fragColor = vec4(emission, 0.0);
}
