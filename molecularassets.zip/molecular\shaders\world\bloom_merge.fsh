#version 330 core

uniform sampler2D Sampler0;
in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec3 bloom = texture(Sampler0, texCoord).rgb * 0.82;
    if (max(bloom.r, max(bloom.g, bloom.b)) <= 0.00001) {
        discard;
    }
    fragColor = vec4(bloom, 0.0);
}
