#version 330 core

in vec2 quadCoord;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec2 centered = quadCoord * 2.0 - 1.0;
    float distanceSquared = dot(centered, centered);
    if (distanceSquared >= 1.0) {
        discard;
    }

    const float sharpness = 4.5;
    const float edgeValue = exp(-sharpness);
    float falloff = (exp(-sharpness * distanceSquared) - edgeValue) / (1.0 - edgeValue);
    float alpha = vertexColor.a * clamp(falloff, 0.0, 1.0);
    if (alpha <= 0.001) {
        discard;
    }

    fragColor = vec4(vertexColor.rgb, alpha);
}
