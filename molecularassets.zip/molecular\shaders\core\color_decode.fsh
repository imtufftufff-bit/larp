#version 330 core

#include <molecular:color.glsl>

uniform sampler2D Sampler0;

in vec2 texCoord0;

out vec4 fragColor;

void main() {
    ivec2 size = textureSize(Sampler0, 0);
    vec2 footprint = max(fwidth(texCoord0), 1.0 / vec2(size));
    vec3 color = vec3(0.0);
    for (int y = 0; y < 4; y++) {
        for (int x = 0; x < 4; x++) {
            vec2 offset = (vec2(x, y) + 0.5) * 0.25 - 0.5;
            ivec2 position = ivec2(floor((texCoord0 + offset * footprint) * vec2(size)));
            vec3 encoded = texelFetch(Sampler0, clamp(position, ivec2(0), size - 1), 0).rgb;
            color += srgbToLinear(encoded);
        }
    }
    fragColor = vec4(color * (1.0 / 16.0), 1.0);
}
