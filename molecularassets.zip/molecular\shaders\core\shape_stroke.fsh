#version 330 core

#include <molecular:common.glsl>
#include <molecular:color.glsl>

in vec2 quadCoord;
in vec4 vertexColor;
in vec4 vertexData0;
in vec4 vertexData1;

out vec4 fragColor;

void main() {
    vec2 size = max(vertexData1.xy, vec2(0.0001));
    vec2 halfSize = size * 0.5;
    float radius = clamp(vertexData1.z, 0.0, min(halfSize.x, halfSize.y));
    float thickness = clamp(vertexData1.w, 0.0, min(halfSize.x, halfSize.y));
    float softness = max(vertexData0.z, 0.0) * 0.5;
    vec2 position = quadCoord * size - halfSize;
    float outerDistance = roundedBoxSDF(position, halfSize, vec4(radius));
    float outerAA = max(fwidth(outerDistance) * 0.5, max(softness, 0.0001));
    float outerCoverage = 1.0 - smoothstep(-outerAA, outerAA, outerDistance);
    vec2 innerHalfSize = halfSize - thickness;
    float innerDistance = roundedBoxSDF(position, innerHalfSize, vec4(max(radius - thickness, 0.0)));
    float innerAA = max(fwidth(innerDistance) * 0.5, max(softness, 0.0001));
    float innerCoverage = 1.0 - smoothstep(-innerAA, innerAA, innerDistance);
    innerCoverage *= step(0.0001, min(innerHalfSize.x, innerHalfSize.y));
    innerCoverage = min(outerCoverage, innerCoverage);
    float strokeAlpha = max(outerCoverage - innerCoverage, 0.0) * vertexColor.a;
    float fillAlpha = innerCoverage * vertexData0.y;
    float alpha = strokeAlpha + fillAlpha;

    if (alpha <= 0.0001) {
        discard;
    }

    uint packedColor = uint(vertexData0.x);
    vec3 fill = vec3((packedColor >> 16u) & 255u, (packedColor >> 8u) & 255u, packedColor & 255u) / 255.0;
    vec3 color = vertexColor.rgb * strokeAlpha + srgbToLinear(fill) * fillAlpha;
    fragColor = vec4(color, alpha);
}
