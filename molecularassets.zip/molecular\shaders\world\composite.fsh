#version 330 core

#include <molecular:color.glsl>

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec4 scene = texture(Sampler0, texCoord);
    vec4 overlay = texture(Sampler1, texCoord);
    if (all(equal(overlay, vec4(0.0)))) {
        fragColor = scene;
        return;
    }
    float alpha = clamp(overlay.a, 0.0, 1.0);
    vec3 linear = srgbToLinear(scene.rgb) * (1.0 - alpha) + overlay.rgb;
    float dither = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715)))) - 0.5;
    vec3 encoded = linearToSrgb(linear) + dither / 255.0;
    fragColor = vec4(clamp(encoded, 0.0, 1.0), alpha + scene.a * (1.0 - alpha));
}
