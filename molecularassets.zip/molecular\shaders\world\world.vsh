#version 330 core

#include <molecular:color.glsl>
#include <molecular:frame.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec4 ModelRow0;
layout(location = 3) in vec4 ModelRow1;
layout(location = 4) in vec4 ModelRow2;
layout(location = 5) in vec4 InstanceColor;
layout(location = 6) in vec4 InstanceData;
uniform bool Instanced;

out vec4 vertexColor;
out float vertexEmission;

void main() {
    vec4 local = vec4(Position, 1.0);
    vec3 relative = Instanced ? vec3(dot(ModelRow0, local), dot(ModelRow1, local), dot(ModelRow2, local)) : Position;
    gl_Position = FrameViewProjection * vec4(relative, 1.0);
    vec4 tint = Instanced ? InstanceColor : vec4(1.0);
    vertexColor = vec4(srgbToLinear(Color.rgb) * srgbToLinear(tint.rgb), Color.a * tint.a);
    vertexEmission = Instanced ? InstanceData.x : 0.0;
}
