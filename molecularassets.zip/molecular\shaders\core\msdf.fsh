#version 330 core

uniform sampler2D Sampler0;

in vec2 texCoord0;
in vec4 vertexColor;
in vec4 vertexData0;
in vec4 vertexData1;

out vec4 fragColor;

float median(float r, float g, float b) {
    return max(min(r, g), min(max(r, g), b));
}

float screenPxRange() {
    vec2 unitRange = vec2(max(vertexData0.x, 0.001)) / vec2(textureSize(Sampler0, 0));
    vec2 screenTexSize = vec2(1.0) / max(fwidth(texCoord0), vec2(0.0000001));
    return max(0.5 * dot(unitRange, screenTexSize), 1.0);
}

void main() {
    vec4 field = texture(Sampler0, texCoord0);
    float threshold = clamp(vertexData0.y, 0.0001, 0.9999);
    float range = screenPxRange();
    float msdf = median(field.r, field.g, field.b);
    float fillDistance = range * (msdf - threshold);
    float trueDistance = range * ((vertexData0.z > 0.5 ? field.a : msdf) - threshold);
    float fillAlpha = clamp(fillDistance + 0.5, 0.0, 1.0);
    float budget = max(0.0, range * threshold - 1.0);
    float outlineWidth = min(max(vertexData0.w, 0.0), budget);
    float outlineAlpha = outlineWidth > 0.0
            ? max(clamp(trueDistance + outlineWidth + 0.5, 0.0, 1.0), fillAlpha) : fillAlpha;
    float shadowAlpha = 0.0;
    float requestedBlur = max(vertexData1.x, 0.0);
    vec2 requestedOffset = vertexData1.yz;
    float extent = requestedBlur + length(requestedOffset);
    float effectScale = extent > 0.0 ? min(1.0, budget / extent) : 1.0;
    float blur = requestedBlur * effectScale;
    vec2 offset = requestedOffset * effectScale;
    float influence = blur + length(offset);
    vec2 uvDx = dFdx(texCoord0);
    vec2 uvDy = dFdy(texCoord0);
    if (vertexData1.w > 0.0 && budget > 0.0 && trueDistance >= -influence - 0.5) {
        vec2 shadowUv = texCoord0 - uvDx * offset.x + uvDy * offset.y;
        vec4 shifted = textureGrad(Sampler0, shadowUv, uvDx, uvDy);
        float distance = range * ((vertexData0.z > 0.5
                ? shifted.a : median(shifted.r, shifted.g, shifted.b)) - threshold);
        shadowAlpha = smoothstep(-blur - 0.5, blur + 0.5, distance) * clamp(vertexData1.w, 0.0, 1.0);
    }
    float alpha = outlineAlpha + shadowAlpha * (1.0 - outlineAlpha);
    if (alpha <= 0.0) {
        discard;
    }
    fragColor = vec4(vertexColor.rgb * (fillAlpha / alpha), vertexColor.a * alpha);
}
