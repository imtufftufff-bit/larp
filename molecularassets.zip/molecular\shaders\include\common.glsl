float roundedCornerRadius(vec2 centerPosition, vec2 halfSize, vec4 radii) {
    vec4 safeRadii = max(radii, vec4(0.0));
    float radius;

    if (centerPosition.x > 0.0) {
        radius = centerPosition.y > 0.0 ? safeRadii.x : safeRadii.y;
    } else {
        radius = centerPosition.y > 0.0 ? safeRadii.z : safeRadii.w;
    }

    return min(radius, max(min(halfSize.x, halfSize.y), 0.0));
}

float roundedBoxSDF(vec2 centerPosition, vec2 halfSize, vec4 radii) {
    vec2 safeHalfSize = max(halfSize, vec2(0.0001));
    float radius = roundedCornerRadius(centerPosition, safeHalfSize, radii);
    vec2 edgeDistance = abs(centerPosition) - safeHalfSize + radius;
    return min(max(edgeDistance.x, edgeDistance.y), 0.0)
        + length(max(edgeDistance, vec2(0.0))) - radius;
}

const vec2[4] RECT_VERTICES_COORDS = vec2[](
    vec2(0.0, 0.0),
    vec2(0.0, 1.0),
    vec2(1.0, 1.0),
    vec2(1.0, 0.0)
);

vec2 rvertexcoord(int id) {
    return RECT_VERTICES_COORDS[id % 4];
}
