#version 330 core

#include <molecular:color.glsl>
#include <molecular:frame.glsl>

layout(location = 0) in vec2 Position;
layout(location = 1) in vec2 UV0;
layout(location = 2) in vec4 Color;
layout(location = 3) in vec4 Data0;
layout(location = 4) in vec4 Data1;
layout(location = 5) in vec4 InstanceOriginAxis;
layout(location = 6) in vec4 InstanceAxisUv;
layout(location = 7) in vec4 InstanceUvColor;
uniform bool Instanced;

out vec2 texCoord0;
out vec2 quadCoord;
out vec2 screenPosition;
out vec4 vertexColor;
out vec4 vertexData0;
out vec4 vertexData1;

void main() {
    vec2 position = Position;
    vec2 uv = UV0;
    vec4 color = Color;
    if (Instanced) {
        vec2 corner = vec2(gl_VertexID >= 2 ? 1.0 : 0.0,
                gl_VertexID == 1 || gl_VertexID == 2 ? 1.0 : 0.0);
        position = InstanceOriginAxis.xy + InstanceOriginAxis.zw * corner.x + InstanceAxisUv.xy * corner.y;
        uv = mix(InstanceAxisUv.zw, InstanceUvColor.xy, corner);
        uint rgb = uint(InstanceUvColor.z);
        color = vec4(vec3((rgb >> 16u) & 255u, (rgb >> 8u) & 255u, rgb & 255u) / 255.0, InstanceUvColor.w);
    }
    vec2 safeScreen = max(TargetSize.xy, vec2(1.0));
    vec2 normalized = (position / safeScreen - ActiveUv.xy) / ActiveUv.zw;
    gl_Position = vec4(normalized.x * 2.0 - 1.0, 1.0 - normalized.y * 2.0, 0.0, 1.0);
    texCoord0 = uv;
    quadCoord = uv;
    screenPosition = position;
    vertexColor = vec4(srgbToLinear(color.rgb), color.a);
    vertexData0 = Data0;
    vertexData1 = Data1;
}
