#version 330 core

layout(location = 0) in vec2 Position;
layout(location = 1) in vec2 UV0;
layout(location = 2) in vec4 Color;
layout(location = 3) in vec4 Data0;
layout(location = 4) in vec4 Data1;

uniform vec2 ScreenSize;

out vec2 texCoord0;
out vec2 quadCoord;
out vec2 screenPosition;
out vec4 vertexColor;
out vec4 vertexData0;
out vec4 vertexData1;

void main() {
    vec2 safeScreen = max(ScreenSize, vec2(1.0));
    vec2 normalized = Position / safeScreen;
    gl_Position = vec4(normalized.x * 2.0 - 1.0, 1.0 - normalized.y * 2.0, 0.0, 1.0);
    texCoord0 = UV0;
    quadCoord = vec2(UV0.x, UV0.y);
    screenPosition = Position;
    vertexColor = Color;
    vertexData0 = Data0;
    vertexData1 = Data1;
}
