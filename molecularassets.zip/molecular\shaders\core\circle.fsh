#version 330 core

in vec2 quadCoord;
in vec4 vertexColor;
in vec4 vertexData0;

out vec4 fragColor;

void main() {
    float radius = vertexData0.x;
    float outerRadius = vertexData0.y;
    float smoothness = vertexData0.z;
    vec2 local = (quadCoord * 2.0 - 1.0) * outerRadius;
    float distance = length(local) - radius;
    float edgeWidth = max(fwidth(distance) * 0.75, max(smoothness * 0.5, 0.0001));
    float alpha = 1.0 - smoothstep(-edgeWidth, edgeWidth, distance);
    vec4 finalColor = vec4(vertexColor.rgb, vertexColor.a * alpha);

    if (finalColor.a <= 0.001) {
        discard;
    }
    fragColor = finalColor;
}
