#version 330 core

in vec4 vertexColor;
in float vertexEmission;
out vec4 fragColor;

void main() {
    float strength = max(vertexEmission, 0.0);
    vec3 emission = vertexColor.rgb * vertexColor.a * strength;
    if (max(emission.r, max(emission.g, emission.b)) <= 0.00001) {
        discard;
    }
    fragColor = vec4(emission, 0.0);
}
