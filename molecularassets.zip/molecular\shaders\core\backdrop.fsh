#version 330 core

#include <molecular:common.glsl>

uniform sampler2D Sampler0;
uniform vec4 BackdropRegion;

in vec2 quadCoord;
in vec2 screenPosition;
in vec4 vertexColor;
in vec4 vertexData0;
in vec4 vertexData1;

out vec4 fragColor;

void main() {
    vec2 size = max(vertexData0.xy, vec2(0.0001));
    float radius = max(vertexData0.z, 0.0);
    float distance = roundedBoxSDF((quadCoord - 0.5) * size, size * 0.5, vec4(radius));
    float edgeWidth = max(fwidth(distance) * 0.75, 0.0001);
    float coverage = 1.0 - smoothstep(-edgeWidth, edgeWidth, distance);
    float alpha = coverage * clamp(vertexData0.w, 0.0, 1.0) * vertexColor.a;
    if (alpha <= 0.0001) {
        discard;
    }
    vec2 uv = BackdropRegion.z > 0.0
            ? (screenPosition - BackdropRegion.xy) / BackdropRegion.zw
            : screenPosition / max(vertexData1.xy, vec2(1.0));
    uv.y = 1.0 - uv.y;
    vec3 blurred = texture(Sampler0, uv).rgb;
    float luminance = dot(blurred, vec3(0.2126, 0.7152, 0.0722));
    vec3 desaturated = mix(vec3(luminance), blurred, clamp(vertexData1.w, 0.0, 1.0));
    vec3 color = mix(desaturated, vertexColor.rgb, clamp(vertexData1.z, 0.0, 1.0));
    fragColor = vec4(color * alpha, alpha);
}
